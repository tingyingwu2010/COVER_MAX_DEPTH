#include "global_variables.h"

///////////////////////////////
/*     INPUT DATA            */
 double *profits;
 vector < int > weights;
 int capacity;
 int item_number;
 //int item_input;
 //int cap_input;
 //////////////////////////////

 int cat;
 int R;

///////////////////////////////
/*      INPUT PARAMETERS     */
 double timeLimit;
 char *istname;
 int algo;
 int option;
///////////////////////////////



